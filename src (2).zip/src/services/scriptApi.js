import {
    setRuntimeVariable,
    getRuntimeVariable,
    hasRuntimeVariable,
    removeRuntimeVariable,
    clearRuntimeVariables,
} from "./scriptRuntime"

export const api = {

    set(key, value) {
        setRuntimeVariable(key, value)
    },

    get(key) {
        return getRuntimeVariable(key)
    },

    has(key) {
        return hasRuntimeVariable(key)
    },

    remove(key) {
        removeRuntimeVariable(key)
    },

    clear() {
        clearRuntimeVariables()
    },

}