const runtimeVariables = new Map()

export function setRuntimeVariable(key, value) {
    if (!key) {
        return
    }

    runtimeVariables.set(
        String(key),
        value
    )
}

export function getRuntimeVariable(key) {
    if (!key) {
        return undefined
    }

    return runtimeVariables.get(
        String(key)
    )
}

export function hasRuntimeVariable(key) {
    if (!key) {
        return false
    }

    return runtimeVariables.has(
        String(key)
    )
}

export function removeRuntimeVariable(key) {
    if (!key) {
        return
    }

    runtimeVariables.delete(
        String(key)
    )
}

export function clearRuntimeVariables() {
    runtimeVariables.clear()
}

export function getAllRuntimeVariables() {
    return Object.fromEntries(
        runtimeVariables.entries()
    )
}